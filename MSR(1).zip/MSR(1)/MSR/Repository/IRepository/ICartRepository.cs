﻿using MSR.Models;

namespace MSR.Repository.IRepository
{
    public interface ICartRepository
    {
        Task<Cart> AddToCart(int productId, int userId);
        Task<List<Cart>> GetAllCartItems(int userId);

        Task<int> GetToTalPrice(int userId);
        Task<Cart> RemoveItem(int productId, int userId);
    }
}
