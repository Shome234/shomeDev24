﻿using MSR.Models;

namespace MSR.Repository.IRepository
{
    public interface IOrderRepository
    {
        Task<List<Order>> Get();
        Task<Order> BuyNow(int userId);
        Task<int> GetTotalAmount(int userId);
    }
}
