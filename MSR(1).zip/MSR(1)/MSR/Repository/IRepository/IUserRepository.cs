﻿using MSR.Models;

namespace MSR.Repository.IRepository
{
    public interface IUserRepository
    {
        Task<List<User>> Get();
        Task<User> GetById(int id);
        Task<User> Insert(User user);
        Task<User> UserExists(User user);
        Task<User> Update(int id, User user);
        string Delete(int id);
        Task<User> UpdateAsAdmin(int id);
        string Login(string UserEmail, string Password);
    }
}
