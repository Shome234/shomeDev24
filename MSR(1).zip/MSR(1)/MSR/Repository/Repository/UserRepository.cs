﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MSR.Models;
using MSR.Repository.IRepository;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MSR.Repository.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly MSRDbContext _context;
        private readonly IConfiguration _configuration;

        public UserRepository(MSRDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        public async Task<List<User>> Get()
        {
            return await _context.User.ToListAsync();
        }

        public async Task<User> GetById(int id)
        {
            var user = await _context.User.FindAsync(id);

            if (user == null)
            {
                return null;
            }

            return user;
        }

        public async Task<User> Update(int id, User user)
        {
            var result = _context.User.FirstOrDefault(x => x.UserId == id);
            if (result == null) { return null; }
            result.UserName = user.UserName;
            result.Password = user.Password;
            result.ConfirmPassword = user.ConfirmPassword;
            result.UserEmail = user.UserEmail;
            //result.Role = user.Role;
            result.Address = user.Address;
            result.PhoneNumber = user.PhoneNumber;
            _context.SaveChanges();
            return result;
        }
        public async Task<User> UserExists(User user)
        {
            return await _context.User.FirstOrDefaultAsync(x=>x.UserEmail==user.UserEmail);
        }
        public async Task<User> Insert(User user)
        {
            var Userdetail = user;
            Userdetail.Role = "User";
            _context.User.AddAsync(Userdetail);
            await _context.SaveChangesAsync();            
            return user;
        }

        /*        public async Task<User> Delete(int id)
                {
                    var result = await _context.User.FirstOrDefaultAsync(x => x.UserId == id);
                    if (result == null)
                    {
                        return null;
                    }

                    _context.Users.Remove(result);
                    await _context.SaveChangesAsync();

                    return result;
                }*/
        public string Delete(int id)
        {
            try
            {
                var result = _context.User.FirstOrDefault(x => x.UserId == id);
                _context.User.Remove(result);
                _context.SaveChanges();
                return $"The User Id {id} has deleted Succesfully.";
            }
            catch
            {
                return $"The User Id {id} doesn't exsist.";
            }
        }
        public async Task<User> UpdateAsAdmin(int id)
        {
            var result =await  _context.User.FirstOrDefaultAsync(x => x.UserId == id);
            if (result == null)
            {
                return null;
            }
            result.Role = "Admin";
            _context.SaveChanges();
            return result;
        }
        public string Login(string UserEmail, string Password)
        {
            var userExist = _context.User.FirstOrDefault(t => t.UserEmail == UserEmail && EF.Functions.Collate(t.Password, "SQL_Latin1_General_CP1_CS_AS") == Password);
            if (userExist != null)
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                var claims = new[]
                {
             new Claim(ClaimTypes.Email,userExist.UserEmail),
             new Claim("UserId",userExist.UserId.ToString()),
             new Claim(ClaimTypes.Role,userExist.Role)
         };
                var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
                    _configuration["Jwt:Audience"],
                    claims,
                    expires: DateTime.Now.AddMinutes(30),
                    signingCredentials: credentials);
                return new JwtSecurityTokenHandler().WriteToken(token);

            }
            return null;
        }
    }
}
