﻿using MSR.Exception;
using MSR.Models;
using MSR.Repository.IRepository;
using MSR.Service.IService;

namespace MSR.Service.Service
{
    public class CategoryService:ICategoryService
    {
        private readonly ICategoryRepository _catrepo;
        public CategoryService(ICategoryRepository catrepo)
        {
            _catrepo = catrepo;
        }
        public async Task<List<Category>> Get()
        {
            return await _catrepo.Get();
        }
        public async Task<Category> GetById(int id)
        {
            if (await _catrepo.GetById(id) == null)
            {
                throw new CategoryNotFoundException($"The Category with Id {id} is not found");
            }
            return await _catrepo.GetById(id);
        }
        public async Task<Category> Insert(Category category)
        {
            return await _catrepo.Insert(category);
        }
        public async Task<Category> Update(int id, Category category)
        {
            if(await _catrepo.GetById(id)==null)
            {
                throw new CategoryNotFoundException($"The Category with Id {id} is not found");
            }
            return await _catrepo.Update(id, category);
        }
        public async Task<Category> Delete(int id)
        {
            if (await _catrepo.GetById(id) == null)
            {
                throw new CategoryNotFoundException($"The Category with Id {id} is not found");
            }
            return await _catrepo.Delete(id);
        }
    }
}

