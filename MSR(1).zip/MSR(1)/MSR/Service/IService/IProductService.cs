﻿using MSR.Models;

namespace MSR.Service.IService
{
    public interface IProductService
    {
        Task<List<Product>> Get();
        Task<Product> GetById(int id);
        Task<List<Product>> ProductByCategoryName(string categoryname);
        Task<Product> Insert(Product product);
        Task<List<Product>> GetByPrice(int price);
        Task<Product> Update(int id, Product product);
        Task<Product> Delete(int id);
    }
}
