﻿using MSR.Models;

namespace MSR.Service.IService
{
    public interface IOrderService
    {
        Task<List<Order>> Get();
        Task<Order> BuyNow(int userId);
        Task<int> GetTotalAmount(int userId);
    }
}
