﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MSR.Aspects;
using MSR.Repository.IRepository;
using MSR.Service.IService;

namespace MSR.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class OrderController : ControllerBase
    {
        //private readonly MSRDbContext _context;
        private readonly IOrderService _serv;
        public OrderController(IOrderService serv)
        {
            _serv = serv;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllOrder()
        {
            var result= await _serv.Get();
            return Ok(result);
        }
        [HttpPost]
        [Route("AddOrder")]
        public async Task<IActionResult> BuyNow(int userId)
        {
            var result= await _serv.BuyNow(userId);
            return Ok(result);
        }
        [HttpGet]
        [Route("GetTotalAmount")]

        public async Task<int> GetTotalAmount(int userId)
        {
            var result1 = await _serv.GetTotalAmount(userId);
            return result1;
        }
    }
}
