﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MSR.Aspects;
using MSR.Models;
using MSR.Repository.IRepository;
using MSR.Service.IService;

namespace MSR.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class CategoryController : ControllerBase
    {
        //private readonly MSRDbContext _context;
        private readonly ICategoryService _serv;
        public CategoryController(ICategoryService serv)
        {
            _serv = serv;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllCategory()
        {
            //var result = await _context.Category.ToListAsync();
            var result = await _serv.Get();
            return Ok(result);
        }
        [HttpGet]
        [Route("{id:int}/ByCategoryId")]
        public async Task<IActionResult> GetById([FromRoute] int id)
        {
            //var result = await _context.Category.FirstOrDefaultAsync(x => x.CatId == id);
            //if(result == null) { return NotFound(); }
            var result = await _serv.GetById(id);
            return Ok(result);
        }
        [HttpPost]
        public async Task<IActionResult> InsertCategory(Category category)
        {
            /*await _context.Category.AddAsync(category);
            await _context.SaveChangesAsync();*/
            await _serv.Insert(category);
            return Ok(category);
        }
        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> UpdateCategory([FromRoute] int id, [FromBody] Category category)
        {
            /*var result = await _context.Category.FirstOrDefaultAsync(x => x.CatId == id);
            if(result == null) { return NotFound();}
            result.CatName = category.CatName;
            _context.SaveChanges();*/
            var result = await _serv.Update(id, category);
            return Ok(result);
        }
        [HttpDelete]
        [Route("{id:int}")]
        public async Task<IActionResult> DeleteCtegory([FromRoute] int id)
        {
            /*var result = await _context.Category.FirstOrDefaultAsync(x=>x.CatId == id);
            if(result == null) { return NotFound();}
            _context.Category.Remove(result);
            _context.SaveChanges();*/
            var result = await _serv.Delete(id);
            if(result==null)
            {
                return NotFound();
            }
            return Ok(result);
        }
    }
}
