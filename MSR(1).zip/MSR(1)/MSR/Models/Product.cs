﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSR.Models
{
    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductId { get; set; }
        [Required(ErrorMessage="Product Name is required")]
        public string? ProductName { get; set; }
        [Required(ErrorMessage = "Brand is required")]
        public string? Brand { get; set; }
        [Required(ErrorMessage = "Quantity is required")]
        public int Quantity { get; set; }
        [Required(ErrorMessage = "Product Price is required")]
        public int ProductPrice { get; set; }
        [ForeignKey("CatId")]
        public int CatId { get; set; }
        //public ICollection<Cart> Cart { get; set; } 
        //public  ICollection<Category> Category { get; set; }
    }
}
