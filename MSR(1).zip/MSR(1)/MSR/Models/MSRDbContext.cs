﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace MSR.Models
{
    public class MSRDbContext : DbContext
    {
        public MSRDbContext(DbContextOptions<MSRDbContext> option) : base(option)
        { }
        public DbSet<User> User { get; set; }
        public DbSet<Category> Category { get; set; }
        public DbSet<Product> Product{ get; set; }
        public DbSet<Cart> Cart { get; set; }
        public DbSet<Order> Order { get; set; }
    }
}
