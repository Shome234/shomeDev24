﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSR.Models
{
    public class Category
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CatId { get; set; }
        [Required(ErrorMessage ="Category Name is Required")]
        public string? CatName { get; set; }
        //public ICollection<Product> Product { get; set; }
    }
}
