﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;


using SchoolDemo.Exceptions;

namespace SchoolDemo.Aspects
{
    public class CustomExceptionHandlerAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var exceptionType = context.Exception.GetType();
            var message = context.Exception.Message;
            if(exceptionType == typeof(UserNotFoundException)) 
            {
                var result = new ConflictObjectResult(message);
                context.Result = result;
            }
            else if(exceptionType == typeof(UserAlredyExistsException)) 
            {
                var result = new NotFoundObjectResult(message);
                context.Result= result;
            }
            else if(exceptionType == typeof(StudentAlreadyExistsException))
            {
                var result = new ConflictObjectResult(message);
                context.Result= result; 
            }
            else if (exceptionType == typeof(StudentNotFoundException))
            {
                var result = new NotFoundObjectResult(message);
                context.Result = result;
            }
            else if(exceptionType == typeof(AssignmentAlreadyExists))
            {
                var result = new ConflictObjectResult(message);
                context.Result = result;
            }
                
        }
    }
}
