﻿using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryClass;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Service.ServiceClass
{
    public class CourseService : ICourseService
    {
        private readonly ICourseRepository _courseRespository;

        public CourseService(ICourseRepository courseRespository)
        {
            _courseRespository = courseRespository;
        }
        public async Task<IEnumerable<Course>> GetAll()
        {
            return await _courseRespository.GetAllCourses();
        }
        public Task<Course> GetCourseById(int id)
        {
            return _courseRespository.GetCourseById(id);
        }
        public Task AddCourse(Course course) 
        {
            return _courseRespository.AddCourse(course);
        }
        public Task UpdateCourse(int id, Course course) 
        {
            return _courseRespository.UpdateCourse(id, course);
        }
        public Task DeleteCourse(int id) 
        {
            return _courseRespository.DeleteCourse(id);
        }
    }
}
