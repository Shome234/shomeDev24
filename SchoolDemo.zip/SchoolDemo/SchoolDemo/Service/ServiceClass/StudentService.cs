﻿using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Service.ServiceClass
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _studentRespository;

        public StudentService (IStudentRepository studentRespository)
        {
            _studentRespository = studentRespository;
        }   
        public async Task<IEnumerable<Student>> GetAllStudents()
        {
            return await _studentRespository.GetAllStudents();
        }

        public Task<Student> GetStudentAsync(int id)
        {
            return _studentRespository.GetStudent(id);

        }
        public Task AddStudentAsync (Student student)
        {
            return _studentRespository.AddStudent(student);
        }
        public Task DeleteStudentAsync (int id)
        {
            return _studentRespository.DeleteStudent(id);
        }
        public Task UpdateStudentAsync (int id, Student student)
        {
            return _studentRespository.UpdateStudent(id,student);
        }
    }
}
