﻿using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using SchoolDemo.Respository.RespositoryClass;

namespace SchoolDemo.Service.ServiceClass
{
    public class EnrollmentService : IEnrollmentService
    {
        private readonly IEnrollmentRepository _enrollmentRespository;
        private readonly ICourseRepository _courseRespository;


        public EnrollmentService(IEnrollmentRepository enrollmentRespository, ICourseRepository courseRepository, IStudentRepository studentRespository)
        {
            _enrollmentRespository = enrollmentRespository;
            _courseRespository = courseRepository;

        }

        public async Task<IEnumerable<Enrollment>> GetEnrollment()
        {
            return await _enrollmentRespository.GetEnrollment();

        }
        public async Task<Enrollment> GetEnrollById(int id)
        {
            return await _enrollmentRespository.GetEnrollmentById(id);
        }
        public async Task<int> AddEnrollment(Enrollment enrollment)
        {
            return await _enrollmentRespository.AddEnrollment(enrollment);
        }
        

        
               
        

        public async Task<int> UpdateEnrollment(int id, Enrollment enrollment)
        {
            return await _enrollmentRespository.UpdateEnrollment(id, enrollment);
        }
        public async Task<int> DeleteEnrollment(int id)
        {
            return await _enrollmentRespository.DeleteEnrollment(id);
        }
    }
}
