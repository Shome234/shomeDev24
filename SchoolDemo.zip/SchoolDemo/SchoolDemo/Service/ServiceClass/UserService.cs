﻿using SchoolDemo.Data;
using SchoolDemo.Exceptions;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Service.ServiceClass
{
    public class UserService : IUserService

    {
        public readonly IUserRepository  _userRespository;

        public UserService (IUserRepository userRespository)
        {
            _userRespository = userRespository;
        }   
        public List<User> GetUsers()
        {
            return _userRespository.GetUsers();
        }

        public User GetUserById(int userId)
        {
            User u = _userRespository.GetUserById(userId);
            
            if(u== null)
            {
                throw new UserNotFoundException($"User with user id{userId} does not exists");
            }
            return u;
        }
        public int AddUser(User user)
        {
            if(_userRespository.GetUserById(user.UserId)!= null)
            {
            throw new UserAlredyExistsException($"User with user id{user.UserId} already exists");
            }

           return _userRespository.AddUser(user);
        }
        public int UpdateUser(int id, User user) { 
           return  _userRespository.UpdateUser(id,user);
        }
        public int DeleteUser(int userId)
        {
            if (_userRespository.GetUserById(userId) == null)
            {
                throw new UserNotFoundException($"User with user id{userId} does not exists");
            }
            return  _userRespository.DeleteUser(userId);
        }
        public bool LoginUser(string email, string password)
        {
            var u = _userRespository.GetUserByEmail(email);
            
            if(u == null)
            {
                throw new UserNotFoundException($"User not exists with this Email");
            }
            if(!u.Password.Equals(password))
            {
                throw new Exception($"Password mismatch");
            }
            return true;
        }

        public string Login(string email, string password)
        {
            return _userRespository.Login(email, password);
        }
    }
}
