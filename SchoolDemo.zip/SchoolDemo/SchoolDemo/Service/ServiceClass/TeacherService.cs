﻿using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryClass;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Service.ServiceClass
{
    public class TeacherService : ITeacherService
    {
        public readonly ITeacherRepository _teacherRespository;

        public TeacherService(ITeacherRepository teacherRespository)
        {
            _teacherRespository = teacherRespository;
        }
        public async Task<IEnumerable<Teacher>> GetAllTeacher()
        {
            return await _teacherRespository.GetAllTeachers();
        }

        public Task<Teacher> GetTeacherById(int id)
        {
            return _teacherRespository.GetTeacherById( id);
        }
        public Task AddTeacher(Teacher teacher) 
        { 
            return _teacherRespository.AddTeacher( teacher);
        }
        public Task UpdateTeacher(int id, Teacher teacher) 
        {
            return _teacherRespository.UpdateTeacher(id, teacher);
        }
        public Task DeleteTeacherById(int id) 
        {
            return _teacherRespository.DeleteTeacherById(id);
        }
    }
}
