﻿using SchoolDemo.Data;
using SchoolDemo.Exceptions;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Service.ServiceClass
{
    public class AssignmentService : IAssignmentService
    {
        private readonly IAssignmentRepository _assignmentRepository;

        public AssignmentService (IAssignmentRepository assignmentRepository)
        {
            _assignmentRepository = assignmentRepository;
        }
        public List<Assignment> GetAllAssignmentR()
        {
            return _assignmentRepository.GetAllAssignments();
        }
        public Assignment GetAssignmentR(int id)
        {
            var a = _assignmentRepository.GetAssignmentById(id);
            if(a == null)
            {
                throw new AssignmentNotFound($"Assignment with assignment id {id} does not exixts. ");
            }
            return a;
        }
        public int AddAssignmentR (Assignment assignment)
        {
            if(_assignmentRepository.GetAssignmentById(assignment.AssignmentId)!=null)
            {
                throw new AssignmentAlreadyExists($"Assignment with assignment id{assignment.AssignmentId} exists");
            }
            return _assignmentRepository.AddAssignment(assignment);
        }
        public int UpdateAssignmentR(int id,  Assignment assignment)
        {
            return _assignmentRepository.UpdateAssignment(id, assignment);
        }
        public int DeleteAssignmentR(int id)
        {
            return _assignmentRepository.DeleteAssignment(id);
        }
    }
}
