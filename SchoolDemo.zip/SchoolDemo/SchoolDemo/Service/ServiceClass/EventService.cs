﻿using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Service.ServiceClass
{
    public class EventService : IEventService
    {
        private readonly IEventRepository _eventRepository;

        public EventService (IEventRepository eventRepository)
        {
            _eventRepository = eventRepository;
        }

        public List<Event> GetAllEvent()
        {
            return _eventRepository.GetAllEvents();
        }
         public Event GetEvent(int id)
        {
            return _eventRepository.GetEventById(id);
        }

        public int AddEvent(Event @event)
        {
            return _eventRepository.AddEvent(@event);
        }

        public int UpdateEvent (int id,  Event @event)
        {
            return _eventRepository.UpdateEvent(id, @event);
        }

        public int DeleteEvent(int id)
        {
            return _eventRepository.DeleteEvent(id);
        }
    }
}
