﻿using SchoolDemo.Models;

namespace SchoolDemo.Service.ServiceInterface
{
    public interface ITeacherService
    {
        Task<IEnumerable<Teacher>> GetAllTeacher();

        Task<Teacher> GetTeacherById(int id);
        Task AddTeacher(Teacher teacher);
        Task DeleteTeacherById(int id);
        Task UpdateTeacher(int id, Teacher teacher);
    }
}
