﻿using SchoolDemo.Models;

namespace SchoolDemo.Service.ServiceInterface
{
    public interface IUserService
    {
        List<User> GetUsers();  
        User GetUserById(int userId);
        int AddUser(User user);
        int UpdateUser(int id,User user);
        int DeleteUser(int userId);
        bool LoginUser(string username,string password);
        string Login(string email, string password);
    }
}
