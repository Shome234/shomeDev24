﻿using SchoolDemo.Models;

namespace SchoolDemo.Service.ServiceInterface
{
    public interface IStudentService

    {
        Task<IEnumerable<Student>> GetAllStudents();
        Task <Student> GetStudentAsync (int id);
        Task AddStudentAsync(Student student);
        Task UpdateStudentAsync (int id, Student student);
        Task DeleteStudentAsync (int id);


    }
}
