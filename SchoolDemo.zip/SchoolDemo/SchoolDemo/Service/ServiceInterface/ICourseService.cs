﻿using SchoolDemo.Models;

namespace SchoolDemo.Service.ServiceInterface
{
    public interface ICourseService
    {
        Task<IEnumerable<Course>> GetAll();
        Task<Course> GetCourseById(int id);
        Task AddCourse(Course course);
        Task UpdateCourse(int id,Course course);   
        Task DeleteCourse(int id);
    }
}
