﻿using SchoolDemo.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace SchoolDemo.Service.ServiceInterface
{
    public interface IEnrollmentService
    {
        Task<IEnumerable<Enrollment>> GetEnrollment();
        Task<Enrollment> GetEnrollById(int id);
        Task<int> AddEnrollment(Enrollment enrollment);
        Task<int> UpdateEnrollment(int id,Enrollment enrollment);
        Task<int> DeleteEnrollment(int id);   
       
         
    }
}
