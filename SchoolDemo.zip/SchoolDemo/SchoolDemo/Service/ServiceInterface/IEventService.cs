﻿using SchoolDemo.Models;

namespace SchoolDemo.Service.ServiceInterface
{
    public interface IEventService
    {
        List<Event> GetAllEvent();
        Event GetEvent(int id);
        int AddEvent(Event e);
        int UpdateEvent(int id,Event e);
        int DeleteEvent(int id);
    }
}
