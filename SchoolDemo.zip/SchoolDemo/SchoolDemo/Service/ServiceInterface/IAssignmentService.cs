﻿using SchoolDemo.Models;

namespace SchoolDemo.Service.ServiceInterface
{
    public interface IAssignmentService
    {
        List<Assignment> GetAllAssignmentR();
        Assignment GetAssignmentR(int id);
        int AddAssignmentR (Assignment assignment);
        int UpdateAssignmentR (int id,Assignment assignment);
        int DeleteAssignmentR (int id);
    }
}
