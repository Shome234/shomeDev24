﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolDemo.Models
{
    public class Enrollment
    {
        [Key]
        public int EnrollmentId { get; set; }
        [Required]
        public string EnrollmentName { get; set;}


        [ForeignKey("Student")]
        public int StudentId {  get; set; }
        //public virtual Student Student { get; set; }
        [ForeignKey("Course")]
        public int CourseId {  get; set; }
       //public virtual Course Course { get; set; }

        



    }
}
