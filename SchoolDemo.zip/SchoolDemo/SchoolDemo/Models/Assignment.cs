﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolDemo.Models
{
    public class Assignment
    {
        [Key]
        public int AssignmentId { get; set; }
        [Required]
        public string AssignmentTitle { get; set; }
        public string AssignmentDescription { get; set; }
        [Required]
        public DateTime DeadLine { get; set; }
        public DateTime AssignedDate { get; set; }


        [ForeignKey("Course")]
        public int CourseId {  get; set; }
         //public virtual Course Course { get; set; }
    }
}
