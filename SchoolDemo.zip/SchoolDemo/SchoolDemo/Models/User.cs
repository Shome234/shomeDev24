﻿using System.ComponentModel.DataAnnotations;

namespace SchoolDemo.Models
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string UserType {  get; set; }

        public virtual Teacher Teacher { get; set; }
        public virtual Student Student { get; set; }

        
    }
}
