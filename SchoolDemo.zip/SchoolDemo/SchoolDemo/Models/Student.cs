﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolDemo.Models
{
    public class Student
    {
        [Key]
        public int StudentId {  get; set; }
        [Required]
        public string StudentName { get; set;}
        public DateTime DateOfBirth { get; set; }   
        public string Gender { get; set; }


        [ForeignKey("User")]
        public int UserId {  get; set; }
        //public virtual User User {get; set;}


    }
}
