﻿using System.ComponentModel.DataAnnotations;

namespace SchoolDemo.Models
{
    public class Event
    {
        [Key]
        public int EventId { get; set; }
        [Required]
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public DateTime EventDateTime { get; set; }
    }
}
