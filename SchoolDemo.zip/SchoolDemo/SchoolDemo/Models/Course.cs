﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolDemo.Models
{
    public class Course
    {
        [Key]
        public int CourseId {  get; set; }
        [Required]
        public string CourseName { get; set; }
        public string Description { get; set; }
        public string CourseMaterial {  get; set; }

        [ForeignKey("Teacher")]
        public int TeacherId {  get; set; }
        public virtual Teacher Teacher { get; set; }

       //public virtual ICollection<Enrollment> Enrollments {  get; set; }
       // public virtual ICollection<Chapter> Chapters { get; set; }
       //public virtual ICollection<Assignment> Assignments { get; set; }

    }
}
