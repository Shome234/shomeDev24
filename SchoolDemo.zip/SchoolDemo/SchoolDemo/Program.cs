﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SchoolDemo.Data;
using SchoolDemo.Respository.RespositoryClass;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceClass;
using SchoolDemo.Service.ServiceInterface;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Builder;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<SchoolDemoContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("SchoolDemoContext") ?? throw new InvalidOperationException("Connection string 'SchoolDemoContext' not found.")));

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<ITeacherRepository, TeacherRepository>();
builder.Services.AddScoped<ITeacherService,TeacherService>();
builder.Services.AddScoped<ICourseService,CourseService>();
builder.Services.AddScoped<ICourseRepository,CourseRepository>();
builder.Services.AddTransient<IStudentRepository,StudentRepository>();    
builder.Services.AddTransient<IStudentService,StudentService>();  
builder.Services.AddTransient<IEnrollmentRepository,EnrollmentRepository>();
builder.Services.AddTransient<IEnrollmentService,EnrollmentService>(); 
builder.Services.AddScoped<IAssignmentRepository,AssignmentRepository>();
builder.Services.AddScoped<IAssignmentService,AssignmentService>();
builder.Services.AddScoped<IEventRepository,EventRepository>();
builder.Services.AddScoped<IEventService,EventService>();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidAudience = builder.Configuration["JWT:Audience"],
            ValidIssuer = builder.Configuration["JWT:Issuer"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Key"]))
        };
    });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
