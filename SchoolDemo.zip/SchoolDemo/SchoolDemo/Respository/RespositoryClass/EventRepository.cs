﻿using SchoolDemo.Data;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;

namespace SchoolDemo.Respository.RespositoryClass
{
    public class EventRepository : IEventRepository
    {
        private readonly SchoolDemoContext _context;

        public EventRepository (SchoolDemoContext context)
        {
            _context = context;
        }

        public List<Event> GetAllEvents()
        {
            return _context.Event.ToList();
        }

        public Event GetEventById(int id)
        {
            return  _context.Event.Where(x=>x.EventId== id).FirstOrDefault();   
        
        }
        public int AddEvent(Event e) 
        {
            _context.Event.Add(e);
            return _context.SaveChanges();
        }

        public int UpdateEvent(int id ,Event e) 
        { 
            var eventsTomodify = _context.Event.Where(x=> x.EventId==id).FirstOrDefault();
            eventsTomodify.EventName=e.EventName;
            eventsTomodify.EventDescription=e.EventDescription;
            eventsTomodify.EventDateTime=e.EventDateTime;
            //_context.Event.Add(e).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            return _context.SaveChanges();
        }

        public int DeleteEvent(int id)
        {
            var e = _context.Event.Where(x => x.EventId == id).FirstOrDefault();
            _context.Event.Remove(e);
            return _context.SaveChanges();
        }
    }
}
