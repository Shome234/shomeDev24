﻿using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;

namespace SchoolDemo.Respository.RespositoryClass
{
    public class AssignmentRepository : IAssignmentRepository
    {
        private readonly SchoolDemoContext _context;

        public AssignmentRepository(SchoolDemoContext context)
        {
            _context = context;
        }

        public List<Assignment> GetAllAssignments()
        {
            return _context.Assignments.ToList();
        }

        public Assignment GetAssignmentById(int id)
        {
            return _context.Assignments.Where(x => x.AssignmentId == id).FirstOrDefault(); 

        }

        public int AddAssignment(Assignment assignment)
        {
            _context.Assignments.Add(assignment);
            return _context.SaveChanges();
        }

        public int UpdateAssignment(int id, Assignment assignment)
        {
            var assign = _context.Assignments.Where(x=>x.AssignmentId==id).FirstOrDefault();
            assign.AssignmentTitle = assignment.AssignmentTitle;
            assign.AssignmentDescription = assignment.AssignmentDescription;
            assign.DeadLine = assignment.DeadLine;
            assign.AssignedDate = assignment.AssignedDate;
            //_context.Entry(assignment).State = EntityState.Modified;
            return _context.SaveChanges();
        }
        public int DeleteAssignment(int id)
        {
            var assign = _context.Assignments.Where(x => x.AssignmentId == id).FirstOrDefault();
            _context.Assignments.Remove(assign);
            return _context.SaveChanges();

        }
    }
        
    }

