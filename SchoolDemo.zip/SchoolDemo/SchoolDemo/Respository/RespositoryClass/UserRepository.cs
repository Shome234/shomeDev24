﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SchoolDemo.Data;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace SchoolDemo.Respository.RespositoryClass
{
    public class UserRepository : IUserRepository
    {
        private readonly SchoolDemoContext _context;
        private readonly IConfiguration _configuration;

        public UserRepository(SchoolDemoContext context)
        {
            _context = context;
        }
        public List<User> GetUsers()
        {
            return _context.User.ToList();
        }
        public  User GetUserById(int userId) {
            return _context.User.Where(x => x.UserId == userId).FirstOrDefault();
        }
        public  User GetUserByEmail(string email)
        {
            return _context.User.Where(x=> x.Email == email).FirstOrDefault();
            
        }

        public int  AddUser(User user)
        {
            _context.User.Add(user);    
           return  _context.SaveChanges();

        }

        public int  UpdateUser(int id,User user)
        {
            User u = _context.User.Where(x=>x.UserId==id).FirstOrDefault();
            u.UserName = user.UserName;
            u.UserType = user.UserType;
            u.Email = user.Email;
            u.Password  =user.Password;
            _context.User.Add(u).State = EntityState.Modified;
            return  _context.SaveChanges();
        }

        public int DeleteUser(int userId)
        {
            User u = _context.User.Where(x => x.UserId == userId).FirstOrDefault(); 
            _context.User.Remove(u);
             return  _context.SaveChanges();
            
        }

        public string Login(string email, string password)
        {
            var userExist = _context.User.FirstOrDefault(t => t.Email == email && EF.Functions.Collate(t.Password, "SQL_Latin1_General_CP1_CS_AS") == password);
            if (userExist != null)
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                var claims = new[]
                {
                     new Claim(ClaimTypes.Email,userExist.Email),
                     new Claim("UserId",userExist.UserId.ToString()),
                     new Claim(ClaimTypes.Role,userExist.UserType)
  };
                var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], claims, expires: DateTime.Now.AddMinutes(30), signingCredentials: credentials);
                return new JwtSecurityTokenHandler().WriteToken(token);

            }
            return null;
        }
    }
}
