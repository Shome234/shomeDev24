﻿using SchoolDemo.Respository.RespositoryInterface;
using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using SchoolDemo.Models;

namespace SchoolDemo.Respository.RespositoryClass
{
    public class TeacherRepository : ITeacherRepository
    {
        private readonly SchoolDemoContext _context;

        public TeacherRepository(SchoolDemoContext context)
        {
            _context = context;
        }
        
        public async Task<IEnumerable<Teacher>> GetAllTeachers()
        {
            return await _context.Teacher.ToListAsync();
        }
        public async Task<Teacher> GetTeacherById(int teacherId)
        {
            return await _context.Teacher.FindAsync(teacherId);
        }

        public async Task AddTeacher(Teacher teacher)
        {
            await _context.Teacher.AddAsync(teacher);
            await _context.SaveChangesAsync();

        }

        public async Task UpdateTeacher(int id,Teacher teacher)
        {
            var teach = _context.Teacher.Where(x=>x.TeacherId == id).FirstOrDefault();
            teach.TeacherName= teacher.TeacherName;
            teach.Department=teacher.Department;
            teach.UserId=teacher.UserId;


           // _context.Teacher.Add(teacher).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTeacherById(int teacherId)
        {
            var teacherToDelete = await _context.User.FindAsync(teacherId);
            if (teacherToDelete != null)
            {
                _context.User.Remove(teacherToDelete);
                _context.SaveChangesAsync();
            }
        }
    }
}
