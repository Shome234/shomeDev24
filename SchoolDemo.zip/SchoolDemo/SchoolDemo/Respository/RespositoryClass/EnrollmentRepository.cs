﻿using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace SchoolDemo.Respository.RespositoryClass
{
    public class EnrollmentRepository : IEnrollmentRepository
    {
        private readonly SchoolDemoContext _context;
        public EnrollmentRepository(SchoolDemoContext context) 
        {
            _context = context;
        }
        public async Task<IEnumerable<Enrollment>> GetEnrollment()
        {
            return await _context.Enrollments.ToListAsync();
        }
        public async Task<Enrollment> GetEnrollmentById(int id)
        {
            return await _context.Enrollments.FindAsync(id);
    
        }
        public async Task<int> AddEnrollment(Enrollment enrollment)
        {
            _context.Add(enrollment);
            return await _context.SaveChangesAsync();
        }
        public async Task<int> UpdateEnrollment(int id,Enrollment enrollment)
        {
            Enrollment u = _context.Enrollments.Where(x => x.EnrollmentId == id).FirstOrDefault();
            u.StudentId = enrollment.StudentId;
            u.CourseId = enrollment.CourseId;
            u.EnrollmentName = enrollment.EnrollmentName;
            //_context.Entry(enrollment).State = EntityState.Modified;
            return await _context.SaveChangesAsync();
        }
        public async Task<int> DeleteEnrollment (int id)
        {
            var enrollToDelete = await _context.Enrollments.FindAsync(id);

            _context.Enrollments.Remove(enrollToDelete);
            return await _context.SaveChangesAsync();
        


        }
    }
}
