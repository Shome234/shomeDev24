﻿using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;

namespace SchoolDemo.Respository.RespositoryClass
{
    public class StudentRepository : IStudentRepository

    {
        private readonly SchoolDemoContext _context;

        public StudentRepository(SchoolDemoContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Student>> GetAllStudents()
        {
            return await _context.Student.ToListAsync();
        }
        public async Task<Student> GetStudent(int id)
        {
            return await _context.Student.FindAsync(id);

        }

        public async Task AddStudent(Student student)
        {
            await _context.Student.AddAsync(student);   
            await _context.SaveChangesAsync();
        }

        public async Task UpdateStudent(int id,Student student)
        {
            var s = await _context.Student.FindAsync(id);
            s.StudentName = student.StudentName;
            s.DateOfBirth = student.DateOfBirth;
            s.Gender = student.Gender;
            s.UserId = student.UserId;

            //_context.Student.Add(student).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
             await _context.SaveChangesAsync();

        }
        public async Task DeleteStudent(int id)
        {
            var studentToDelete = await _context.Student.FindAsync( id);
            if(studentToDelete != null)
            {
                _context.Student.Remove(studentToDelete);
                _context.SaveChangesAsync();

            }


        }

    }
}
