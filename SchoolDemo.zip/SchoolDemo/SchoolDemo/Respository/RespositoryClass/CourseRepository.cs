﻿using SchoolDemo.Respository.RespositoryInterface;
using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using SchoolDemo.Models;
using Microsoft.AspNetCore.Http.HttpResults;

namespace SchoolDemo.Respository.RespositoryClass
{
    public class CourseRepository : ICourseRepository
    {
        private readonly SchoolDemoContext _context;

        public CourseRepository(SchoolDemoContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Course>> GetAllCourses()
        {
            return await _context.Course.ToListAsync();
        }

        public async Task<Course> GetCourseById(int id) 
        {
            return await _context.Course.FindAsync(id); 
        }
        public async Task AddCourse(Course course)
        {
            await  _context.Course.AddAsync(course);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateCourse(int id,Course course)
        {
            var c = await _context.Course.FindAsync(id);
            c.CourseName = course.CourseName;
            //c.CourseId = course.CourseId;
            c.Description = course.Description;
            c.CourseMaterial = course.CourseMaterial;
            c.TeacherId = course.TeacherId;
            //context.(course).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
        public async Task DeleteCourse(int id)
        {
            var courseToDelete = await _context.Course.FindAsync(id);
            if (courseToDelete != null) 
            {
                 _context.Course.Remove(courseToDelete);
                 _context.SaveChangesAsync();  
            }
        }
    }
}
