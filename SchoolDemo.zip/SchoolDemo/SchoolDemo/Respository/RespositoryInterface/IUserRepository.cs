﻿using SchoolDemo.Models;

namespace SchoolDemo.Respository.RespositoryInterface
{
    public interface IUserRepository
    {
        List<User>GetUsers();
        User GetUserById(int userId);
        int  AddUser(User user);
        int UpdateUser(int id,User user);
        int DeleteUser(int userId);
        User GetUserByEmail (string email);
        string Login (string email,string password);
    }
}
