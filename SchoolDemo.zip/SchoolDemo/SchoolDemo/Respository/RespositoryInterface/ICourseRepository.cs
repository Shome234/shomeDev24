﻿
using SchoolDemo.Models;

namespace SchoolDemo.Respository.RespositoryInterface
{
    public interface ICourseRepository
    {
        Task<IEnumerable<Course>> GetAllCourses();
        Task<Course> GetCourseById (int id);
        Task AddCourse(Course course);  
        Task UpdateCourse (int id,Course course);  
        Task DeleteCourse(int id);
    }
}
