﻿using SchoolDemo.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SchoolDemo.Respository.RespositoryInterface
{
    public interface IEnrollmentRepository
    {
        Task<IEnumerable<Enrollment>> GetEnrollment();
        Task<Enrollment> GetEnrollmentById(int id);
        Task<int> AddEnrollment(Enrollment enrollment);
        Task<int> UpdateEnrollment(int id,Enrollment enrollment);
        Task<int> DeleteEnrollment(int id);

    }
}
