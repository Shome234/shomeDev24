﻿using SchoolDemo.Models;

namespace SchoolDemo.Respository.RespositoryInterface
{
    public interface IAssignmentRepository
    {
        List<Assignment> GetAllAssignments();
        Assignment GetAssignmentById(int id);
        int AddAssignment(Assignment assignment);
        int UpdateAssignment(int id,Assignment assignment);
        int DeleteAssignment(int id);

    }
}
