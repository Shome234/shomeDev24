﻿using SchoolDemo.Models;

namespace SchoolDemo.Respository.RespositoryInterface
{
    public interface IStudentRepository
    {
        Task<IEnumerable<Student>> GetAllStudents();
        Task<Student> GetStudent(int id);
        Task AddStudent(Student student);
        Task UpdateStudent(int id,Student student);
        Task DeleteStudent(int id);
    }
}
