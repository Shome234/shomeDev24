﻿using SchoolDemo.Models;

namespace SchoolDemo.Respository.RespositoryInterface
{
    public interface IEventRepository
    {
        List<Event> GetAllEvents();
        Event GetEventById(int id);
        int AddEvent(Event events);
        int UpdateEvent(int id,Event events);
        int DeleteEvent(int id);

    }
}
