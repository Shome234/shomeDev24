﻿using SchoolDemo.Models;

namespace SchoolDemo.Respository.RespositoryInterface
{
    public interface ITeacherRepository
    {
        Task<IEnumerable<Teacher>> GetAllTeachers();
        Task <Teacher>  GetTeacherById(int id);
        Task AddTeacher (Teacher teacher);
        Task DeleteTeacherById(int id);
        Task UpdateTeacher(int id,Teacher teacher);
    }
}
