﻿using Microsoft.AspNetCore.Mvc;
using SchoolDemo.Models;
using SchoolDemo.Service.ServiceClass;
using SchoolDemo.Service.ServiceInterface;
using SchoolDemo.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace SchoolDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherController :ControllerBase
    {
        private readonly ITeacherService _teacherservice;

        public TeacherController (ITeacherService teacherservice)
        {
            _teacherservice = teacherservice;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Teacher>>> GetAllTeacher()
        {
            return Ok(await _teacherservice.GetAllTeacher());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTeacher(int id)
        {
            var user = await _teacherservice.GetTeacherById(id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);

        }

        [HttpPost]
        public async Task<IActionResult> AddTeacher([FromBody] Teacher teacher)
        {
            await _teacherservice.AddTeacher(teacher);
            return CreatedAtAction(nameof(GetTeacher), new { id = teacher.TeacherId }, teacher);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTeacher(int id, [FromBody] Teacher teacher)
        {
            /*if (id != teacher.TeacherId)
            {
                return BadRequest();
            }*/
            await _teacherservice.UpdateTeacher(id,teacher);
            return Ok();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletTeacher(int id)
        {
            await _teacherservice.DeleteTeacherById(id);
            return NoContent();
        }


    }
}
