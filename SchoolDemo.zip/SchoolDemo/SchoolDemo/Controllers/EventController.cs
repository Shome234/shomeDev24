﻿using Microsoft.AspNetCore.Mvc;
using SchoolDemo.Models;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly IEventService _eventService;

        public EventController (IEventService eventService)
        {
            _eventService = eventService;
        }

        [HttpGet]
        public IActionResult GetAllEvent()
        {
            return Ok(_eventService.GetAllEvent());
        }
        [HttpGet("{id}")]
        public IActionResult GetEvent(int id)
        {
            return Ok(_eventService.GetEvent(id));
        }
        [HttpPost]
        public IActionResult AddEventByPost(Event @event)
        {
            return Ok(_eventService.AddEvent(@event));
        }
        [HttpPut("{id}")]
        public IActionResult UpdateEventByPut(int id, Event @event)
        {
            return Ok(_eventService.UpdateEvent(id, @event));
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteEvent(int id)
        {
            return Ok(_eventService.DeleteEvent(id));
        }
    }
}
