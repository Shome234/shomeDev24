﻿using Microsoft.AspNetCore.Mvc;
using SchoolDemo.Models;
using SchoolDemo.Service.ServiceClass;
using SchoolDemo.Service.ServiceInterface;
using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace SchoolDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AssignmentController : ControllerBase
    {
        private readonly IAssignmentService _assignmentService;

        public AssignmentController(IAssignmentService assignmentService)
        {
            _assignmentService = assignmentService;
        }
        [HttpGet]
        public IActionResult GetAllAssignment()
        {
            return Ok(_assignmentService.GetAllAssignmentR());
        }
        [HttpGet("{id}")]
        public IActionResult GetAssignment(int id)
        {
            return Ok(_assignmentService.GetAssignmentR(id));
        }
        [HttpPost]
        public IActionResult AddAssignment([FromBody]Assignment assignment) 
        {
            return Ok(_assignmentService.AddAssignmentR(assignment));
        }
        [HttpPut("{id}")]
        public IActionResult UpdateAssignment (int id, [FromBody]Assignment assignment)
        {
            return  Ok(_assignmentService.UpdateAssignmentR(id, assignment)); 
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteAssignment (int id)
        {
            return Ok(_assignmentService.DeleteAssignmentR(id));
        }


    }
}
