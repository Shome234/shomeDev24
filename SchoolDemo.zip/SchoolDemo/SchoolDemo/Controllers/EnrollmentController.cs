﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using SchoolDemo.Models;
using SchoolDemo.Service.ServiceInterface;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using SchoolDemo.Service.ServiceClass;

namespace SchoolDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentController : ControllerBase
    {
        private readonly IEnrollmentService _enrollmentService;

        
        public EnrollmentController(IEnrollmentService enrollmentService)
        {
            _enrollmentService = enrollmentService;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Enrollment>>> GetEnrollment()
        {
            
            
            var enrollments = await _enrollmentService.GetEnrollment();
            if (enrollments != null)
            {
                return Ok(enrollments);
            }
            
            return StatusCode(500);

        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEnrollsById(int id)
        {
            var enroll = await _enrollmentService.GetEnrollById(id);
            if(enroll == null)
            {
                return NotFound();
            }
            return Ok(enroll);
        }
        [HttpPost]
        public async Task<IActionResult> PostEnrollAdding(Enrollment enrollment)
        {
            _enrollmentService.AddEnrollment(enrollment);
            return CreatedAtAction(nameof(GetEnrollsById), new {id = enrollment.EnrollmentId },enrollment);

        }
        [HttpPut]
        public async Task<IActionResult> PutEnrollUpdating (int id, Enrollment enrollment)
        {
            var enroll = await _enrollmentService.GetEnrollById(id);
            if (id == enroll.EnrollmentId)
            {
                await _enrollmentService.UpdateEnrollment(id, enrollment);
                return Ok();
           }
            return BadRequest();

        }
        [HttpDelete]
        public async Task<IActionResult> DeleteEnroll(int id)
        {
            await _enrollmentService.DeleteEnrollment(id);
            return Ok();
        }
        
    }
}
