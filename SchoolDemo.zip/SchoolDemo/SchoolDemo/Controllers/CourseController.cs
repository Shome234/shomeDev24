﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using SchoolDemo.Models;
using SchoolDemo.Respository.RespositoryInterface;
using SchoolDemo.Service.ServiceInterface;

namespace SchoolDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ICourseService   _courseService;

        public CourseController (ICourseService courseService)
        {
            _courseService = courseService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Course>>> GetAllCourses()
        {
            return Ok(await _courseService.GetAll());
        }
        
        [HttpPost]
        public async Task<IActionResult> AddCourse([FromBody] Course course)
        {
            await _courseService.AddCourse(course);
            return CreatedAtAction(nameof(GetCourse), new { id = course.CourseId }, course);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCourseByPut(int id, [FromBody] Course course)
        {
            /*if(id!=course.CourseId)
            {
                return BadRequest();
            }*/
            await _courseService.UpdateCourse( id,course);  
            return Ok();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCourse(int id)
        {
            await _courseService.DeleteCourse(id);
               return NoContent();
        }

        
    }
}
