﻿using Microsoft.AspNetCore.Mvc;
using SchoolDemo.Models;
using SchoolDemo.Service.ServiceClass;
using SchoolDemo.Service.ServiceInterface;
using Microsoft.EntityFrameworkCore;
using SchoolDemo.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using SchoolDemo.Aspects;
using Microsoft.AspNetCore.Authorization;

namespace SchoolDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [CustomExceptionHandler]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }
        [HttpGet]
        [Authorize(Roles ="admin")]
        public IActionResult Get()
        {
            return Ok(_userService.GetUsers());
        }


        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {

            return Ok(_userService.GetUserById(id));

        }
        [HttpPost("Login")]
        public  IActionResult Login([FromBody] User user)
        {
            if (_userService.LoginUser(user.Email, user.Password))
                return Ok("Login Successfully");
            return BadRequest();
        }
        [HttpPost]
        public IActionResult AddUser([FromBody] User user)
            {
            return StatusCode(201,_userService.AddUser(user));  
           
              }

        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id,[FromBody] User user) 
        { 
            return Ok(_userService.UpdateUser(id, user));   
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            return Ok(_userService.DeleteUser(id));
        }

        [HttpPost("[Action]")]
        public IActionResult Log(string email,string password)
        {
            return Ok(_userService.Login(email, password));
        }
    }
}
