﻿namespace SchoolDemo.Exceptions
{
    public class AssignmentAlreadyExists : ApplicationException
    {
        public AssignmentAlreadyExists() { }
        public AssignmentAlreadyExists(string message) : base(message) { }
    }
}
