﻿namespace SchoolDemo.Exceptions
{
    public class UserAlredyExistsException : ApplicationException
    {
        public UserAlredyExistsException() { }
        public UserAlredyExistsException(string message) : base(message) { }
    }
}
