﻿namespace SchoolDemo.Exceptions
{
    public class AssignmentNotFound : ApplicationException
    {
        public AssignmentNotFound() { }
        public AssignmentNotFound(string message) : base(message) { }
    }
}
