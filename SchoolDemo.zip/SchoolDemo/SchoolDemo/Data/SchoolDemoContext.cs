﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SchoolDemo.Models;

namespace SchoolDemo.Data
{
    public class SchoolDemoContext : DbContext
    {
        public SchoolDemoContext (DbContextOptions<SchoolDemoContext> options)
            : base(options)
        {
        }

        public DbSet<SchoolDemo.Models.User> User { get; set; } = default!;
        public DbSet<SchoolDemo.Models.Student> Student { get; set; } = default!;
        public DbSet<SchoolDemo.Models.Teacher> Teacher { get; set; }  
        public DbSet<SchoolDemo.Models.Course> Course { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }  
        public DbSet<Assignment> Assignments { get; set; } = default;
        public DbSet<SchoolDemo.Models.Event> Event { get; set; } = default!;
    }
}
