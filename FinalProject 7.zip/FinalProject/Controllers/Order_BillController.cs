﻿using FinalProject.Repository.CartRepository;
using FinalProject.Repository.Order_BillRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FinalProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Order_BillController : ControllerBase
    {
        private readonly IOrder_Bill order_ItemRepo;
        private readonly ICart cartRepo;

        public Order_BillController(IOrder_Bill order_ItemRepo, ICart cartRepo)
        {
            this.order_ItemRepo = order_ItemRepo;
            this.cartRepo = cartRepo;
        }
        [HttpPost]
       [Authorize(Roles = "CustomerUser")]
        public IActionResult AddOrderedItems(Guid orderId)
        {
            var id = int.Parse(HttpContext.User.FindFirst(c => c.Type == "UserId").Value);
            order_ItemRepo.AddOrderBillsItem(id, orderId);
            return Ok();
        }
        [HttpGet]
        [Route("{amount}/Filterbyprice")]
        //[Authorize(Roles ="CustomerUser")]
        public async Task<ActionResult> FilterByPriceOrder(int amount)
        {
            var result = await order_ItemRepo.FilterByPriceOrder(amount);
            if(result!=null)
            {
                return Ok(result);
            }
            return NotFound("No Order above the entered amount");
        }

    /*    [HttpGet]
        [Route("getOrderItems")]
        [Authorize(Roles ="CustomerUser")]
        public IActionResult GetOrderItems()
        {
            int id = int.Parse(HttpContext.User.FindFirst(t => t.Type == "UserId").Value);
            var result = cartRepo.GetAllCartItems(id);

            return Ok(result);
        }
*/
        [HttpGet("Using OrderId")]
      [Authorize(Roles = "CustomerUser")]
        public IActionResult GetOrderedItems(Guid orderId)
        {
            int id = int.Parse(HttpContext.User.FindFirst(t => t.Type == "UserId").Value);
            var result = order_ItemRepo.GetOrder_Bills(orderId, id);
            return Ok(result);
        }
    }
}
