﻿using FinalProject.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalProject.Repository.Order_BillRepository
{
    public class Order_BillRepository:IOrder_Bill
    {
        private readonly FinalDbContext context;

        public Order_BillRepository(FinalDbContext context)
        {
            this.context = context;
        }
        public void AddOrderBillsItem(int userId, Guid orderId)
        {
            var cartItems = context.Carts.Where(t => t.UserId == userId).ToList();
            foreach (var cartItem in cartItems)
            {
                var orderItem = new Order_Bill
                {
                    ProductId = cartItem.ProductId,
                    OrderId = orderId,
                    ProductName = context.Products.First(t => t.ProductId == cartItem.ProductId).ProductName,
                    UserId = userId,
                    Quantity = cartItem.Quantity,
                    Price = cartItem.UnitPrice,
                    TotalAmount = cartItem.Quantity * cartItem.UnitPrice,

                };
                context.Order_Bills.Add(orderItem);
                context.SaveChanges();

            }
        }
        public async Task<IEnumerable<Order_Bill>> GetOrder_Bills(Guid orderId, int userId)
        {
            var result = context.Order_Bills.Where(t => t.UserId == userId && t.OrderId == orderId).ToList();

            return result;
        }

        public async Task<List<Order_Bill>> FilterByPriceOrder(int amount)
        {
            string filterbyamount = "exec Order_BillPrice @TotalPrice=" + amount;
            return context.Order_Bills.FromSqlRaw(filterbyamount).ToList();

        }
    }
}
