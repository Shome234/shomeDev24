﻿using FinalProject.Models;

namespace FinalProject.Repository.Order_BillRepository
{
    public interface IOrder_Bill
    {
        Task<IEnumerable<Order_Bill>> GetOrder_Bills(Guid orderId,int userId);
        void AddOrderBillsItem(int userId, Guid order_Id);
        Task<List<Order_Bill>> FilterByPriceOrder(int amount);
    }
}
