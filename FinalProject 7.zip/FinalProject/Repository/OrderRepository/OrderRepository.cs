﻿using FinalProject.Models;
using FinalProject.Repository.CartRepository;
using Microsoft.EntityFrameworkCore;

namespace FinalProject.Repository.OrderRepository
{
    public class OrderRepository:IOrder
    {

        private readonly FinalDbContext context;
        private readonly ICart cart;

        public OrderRepository(FinalDbContext context, ICart cart)
        {
            this.context = context;
            this.cart = cart;
        }
        public void BuyNow(int userId)
        {
            var order = new Order
            {
                UserId = userId,
                TotalAmount = GetTotalAmount(userId),
              
                NetAmount = GetTotalAmount(userId) 
};
            context.Orders.Add(order);
            context.SaveChanges();
        }
        public int GetTotalAmount(int userId)
        {
            return cart.GetToTalPrice(userId);
        }
        public int GetNetAmount(int userId)
        {
            return cart.GetToTalPrice(userId);

        }
        
        

      
       
       

    }
}
