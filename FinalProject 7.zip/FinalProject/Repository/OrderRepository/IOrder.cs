﻿using FinalProject.Models;

namespace FinalProject.Repository.OrderRepository
{
    public interface IOrder
    {

        void BuyNow(int userId);
        int GetTotalAmount(int userId);

        int GetNetAmount(int userId);
      
    
    }
}
