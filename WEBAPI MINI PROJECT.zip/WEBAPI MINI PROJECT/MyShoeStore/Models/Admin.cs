﻿namespace MyShoeStore.Models
{
    public class Admin
    {

    }
}
