﻿using System.ComponentModel.DataAnnotations;

namespace MyTrekWeb.Models
{
    public class Difficulty
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        
    }
}
