﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyTrekWeb.Models
{
    public class Trek
    {
        [Key]
        public int Id { get; set; }
        public string ?Name { get; set; }
        public string? Description { get; set; }
        public double LengthInKm { get; set; }
        public string? WalkImageUrl { get; set; }
        [ForeignKey("DifficultyId")]
        public int DifficultyId { get; set; }
        // [ForeignKey("DifficultyId")]
        // public Difficulty Difficulty { get; set; }
        [ForeignKey("RegionId")]
        public int RegionId { get; set; }

       // [ForeignKey("RegionId")]

      //  public Region Region { get; set; }
    }
}
