﻿using System.ComponentModel.DataAnnotations;

namespace MyTrekWeb.Models
{
    public class Region
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MinLength(3)]
        public string Code { get; set; }
        [Required]
        [MaxLength(100,ErrorMessage ="Name has to be a maximum of 100 characters")]
        public string Name { get; set; }
        public string? RegionImageUrl { get; set; }
    }
}
