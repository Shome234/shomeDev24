﻿using Microsoft.AspNetCore.Mvc;
using MyTrekWeb.Exception;
using MyTrekWeb.Models;
using MyTrekWeb.Repository;
using MyTrekWeb.Services.IService;

namespace MyTrekWeb.Services.Service
{
    public class RegionService:IRegionService
    {
        private readonly IRegionRepository _repo;
        public RegionService(IRegionRepository repo)
        {
                _repo = repo;
        }

        public async Task<Region> delete(int id)
        {
            if(await _repo.GetById(id)==null)
            {
                throw new RegionNotFoundException($"The Region id {id} does not exist");
            }
            return await _repo.delete(id);

        }

        public async Task<Region> GetById(int id)
        {
            if (await _repo.GetById(id) == null)
            {
                throw new RegionNotFoundException($"The Region id {id} does not exist");
            }
            return await _repo.GetById(id);
        }

        public async Task<Region> update(int id, Region region)
        {
            if (await _repo.GetById(id) == null)
            {
                throw new RegionNotFoundException($"The Region id {id} does not exist");
            }
            return await _repo.update(id,region);

        }
    }
}
