﻿using Microsoft.AspNetCore.Mvc;
using MyTrekWeb.Models;

namespace MyTrekWeb.Services.IService
{
    public interface IRegionService
    {
        public Task<Region> GetById(int id);
        public Task<Region> update(int id, Region region);
        public Task<Region> delete(int id);
    }
}
