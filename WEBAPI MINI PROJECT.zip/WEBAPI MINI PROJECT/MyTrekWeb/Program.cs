using Microsoft.EntityFrameworkCore;
using MyTrekWeb.Data;
using MyTrekWeb.Repository;
using MyTrekWeb.Services.IService;
using MyTrekWeb.Services.Service;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//
builder.Services.AddDbContext<TrekDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("MyCon")));
//
builder.Services.AddScoped<IRegionRepository,SQLRegionRepository>();

builder.Services.AddScoped<IDifficultyRepository, SQLDifficultyRepository>();

builder.Services.AddScoped<ITrekRepository, SQLTrekRepository>();
builder.Services.AddScoped<IRegionService,RegionService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
