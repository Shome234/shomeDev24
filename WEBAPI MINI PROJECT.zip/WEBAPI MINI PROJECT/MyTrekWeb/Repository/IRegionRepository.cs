﻿using Microsoft.AspNetCore.Mvc;
using MyTrekWeb.Models;

namespace MyTrekWeb.Repository
{
    public interface IRegionRepository
    {
        public List<Region> Get();
        public Task<Region> GetById(int id);
        public Region create (Region region);
        public Task<Region> update (int id,Region region);
        public Task<Region> delete (int id);

    }
}
