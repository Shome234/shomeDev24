﻿using MyTrekWeb.Models;

namespace MyTrekWeb.Repository
{
    public interface IDifficultyRepository
    {
        List<Difficulty> Get();
        Difficulty GetAllById(int id);
        Difficulty create(Difficulty difficulty);
        Difficulty Update(int id, Difficulty difficulty);
        Difficulty DeleteById(int id);

        int Marks(int a, int b);
    }
}
