﻿using MyTrekWeb.Data;
using MyTrekWeb.Models;

namespace MyTrekWeb.Repository
{
    public class SQLTrekRepository : ITrekRepository
    {
        private readonly TrekDbContext context;
        public SQLTrekRepository(TrekDbContext context)
        {
            this.context = context;
        }
        public Trek Create(Trek trek)
        {
           context.Treks.Add(trek);
            context.SaveChanges();
            return trek;
        }

        public Trek DeleteById(int id)
        {
            var result = context.Treks.FirstOrDefault(r => r.Id == id);
            if (result == null)
                return null;
            context.Treks.Remove(result);
            context.SaveChanges();
            return result;
        }

        public List<Trek> Get(string? filterOn = null, string? filterQuery = null, string? sortBy=null, bool isAscending=true )
        {
            var result = context.Treks.AsQueryable();
            if (string.IsNullOrWhiteSpace(filterOn) == false && string.IsNullOrWhiteSpace(filterOn) == false)
            {
                if (filterOn.Equals("Name", StringComparison.OrdinalIgnoreCase))
                { result = result.Where(x => x.Name.Contains(filterQuery)); } 
            }
           //sorting
           if(string.IsNullOrWhiteSpace(sortBy)==false)
            {
                if (sortBy.Equals("Name", StringComparison.OrdinalIgnoreCase))
                {
                   if(isAscending==true)
                    {
                        result=result.OrderBy(x => x.Name);
                    }
                   else 
                    {
                        result = result.OrderByDescending(x => x.Name);
                    }
                }
               else if (sortBy.Equals("LengthInKm", StringComparison.OrdinalIgnoreCase))
                {
                    if (isAscending == true)
                    {
                        result = result.OrderBy(x => x.LengthInKm);
                    }
                    else
                    {
                        result = result.OrderByDescending(x => x.LengthInKm);

                    }
                }
            }
            return result.ToList();
        }

        public Trek GetById(int id)
        {
            var result = context.Treks.FirstOrDefault(r => r.Id == id);
            if (result == null)
                return null;
            return result;
        }

        public Trek Update(int id, Trek trek)
        {
            var result = context.Treks.FirstOrDefault(r => r.Id == id);
            if (result == null)
                return null;


            result.Name = trek.Name;
            result.WalkImageUrl = trek.WalkImageUrl;
            result.Description = trek.Description;
            result.LengthInKm = trek.LengthInKm;    
            return result;
        }
    }
}
