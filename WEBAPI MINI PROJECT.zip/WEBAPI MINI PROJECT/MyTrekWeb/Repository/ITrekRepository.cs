﻿using MyTrekWeb.Models;

namespace MyTrekWeb.Repository
{
    public interface ITrekRepository
    {
        List<Trek> Get(string? filterOn = null, string? filterQuery = null, string ? sortBy=null, bool isAscending=true);
        Trek GetById(int id);
        Trek Create(Trek trek);
        Trek Update(int id,Trek trek); 
        Trek DeleteById(int id);    

    }
}
