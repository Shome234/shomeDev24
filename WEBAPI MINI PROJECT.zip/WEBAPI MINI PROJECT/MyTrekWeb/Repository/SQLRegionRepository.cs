﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyTrekWeb.Data;
using MyTrekWeb.Models;

namespace MyTrekWeb.Repository
{
    public class SQLRegionRepository : IRegionRepository
    {
        private readonly TrekDbContext context;
        public SQLRegionRepository(TrekDbContext context)
        {
                this.context = context;
        }
        public Region create(Region region)
        {
            context.Regions.Add(region);
            context.SaveChanges();
            return region;
        }

        public async Task<Region> delete(int id)
        {
            var result = await  context.Regions.FirstOrDefaultAsync(r => r.Id == id);
            if (result == null)
                return null;
            context.Regions.Remove(result);
            context.SaveChanges();
            return result;

        }

        public List<Region> Get()
        {
            var result = context.Regions.ToList();
            return result;  
        }

        public async Task<Region> GetById(int id)
        {
           var result = await context.Regions.FirstOrDefaultAsync(r => r.Id == id);
            if (result == null)
                return null;
            return result;
        }

        public async Task<Region> update(int id, Region region)
        {
            var result = await context.Regions.FirstOrDefaultAsync(r => r.Id == id);
            if (result == null)
                return null;
            result.Name = region.Name;
            result.Code = region.Code;
            result.RegionImageUrl = region.RegionImageUrl;
            return result;

        }
    }
}
