﻿using MyTrekWeb.Data;
using MyTrekWeb.Models;

namespace MyTrekWeb.Repository
{
    public class SQLDifficultyRepository : IDifficultyRepository
    {
        private readonly TrekDbContext context;
        public SQLDifficultyRepository(TrekDbContext context )
        {
                this.context = context;
        }
        public Difficulty create(Difficulty difficulty)
        {
            context.difficulties.Add(difficulty);
            context.SaveChanges();
            return difficulty;
        }

        public Difficulty DeleteById(int id)
        {
            var result = context.difficulties.FirstOrDefault(r => r.Id == id);
            if(result == null) { return null; }
            context.difficulties.Remove(result);
            context.SaveChanges();
            return result;
        }

        public List<Difficulty> Get()
        {
            var result = context.difficulties.ToList();
            return result;
        }

        public Difficulty GetAllById(int id)
        {
            var result = context.difficulties.FirstOrDefault(r => r.Id == id);
            if (result == null) { return null; }
            return result;
        }

        public int Marks(int a, int b)
        {
            int c = a + b;
            return c;
        }

        public Difficulty Update(int id, Difficulty difficulty)
        {
            var result = context.difficulties.FirstOrDefault(r => r.Id == id);
            if (result == null) { return null; }
           
               

            result.Name = difficulty.Name;
            return result;
        }
    }
}
