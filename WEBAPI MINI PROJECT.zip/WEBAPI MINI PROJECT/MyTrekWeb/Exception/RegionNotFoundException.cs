﻿namespace MyTrekWeb.Exception
{
    public class RegionNotFoundException :ApplicationException
    {
        public RegionNotFoundException() { }
        public RegionNotFoundException(string msg) : base(msg) { }
    }
}
