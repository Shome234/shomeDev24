﻿using Microsoft.EntityFrameworkCore;
using MyTrekWeb.Models;

namespace MyTrekWeb.Data
{
    public class TrekDbContext:DbContext
    {
        public TrekDbContext(DbContextOptions<TrekDbContext> options): base(options) { }
        
       public DbSet<Difficulty> difficulties { get; set; }    
        public DbSet<Region> Regions {  get; set; } 
        public DbSet<Trek> Treks { get; set; }
    }
}
