﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyTrekWeb.Aspects;
using MyTrekWeb.Data;
using MyTrekWeb.Models;
using MyTrekWeb.Repository;
using MyTrekWeb.Services.IService;

namespace MyTrekWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class RegionController : ControllerBase
    {
        //private readonly TrekDbContext context;
        private readonly IRegionRepository regionRepo;
        private readonly IRegionService _serv;
        public RegionController(IRegionRepository repo,IRegionService serv)
        {
           
            regionRepo = repo;
            _serv = serv;
        }
        [HttpGet]   
        public IActionResult Get()
        {
           // var result = context.Regions.ToList();
           var result = regionRepo.Get();
            return Ok(result);  
        }
        [HttpGet]
        [Route("{id:int}")]
        public async Task<IActionResult> GetAllById([FromRoute] int id)
        {
         //var result = context.Regions.FirstOrDefault(x => x.Id == id);  
         var result =await _serv.GetById(id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);  
        }
        [HttpPost]
        public IActionResult create([FromBody] Region region)
        {
            //Model state validation
            if (ModelState.IsValid)
            {
                //context.Regions.Add(region);
                //context.SaveChanges();
                regionRepo.create(region);
                return CreatedAtAction(nameof(GetAllById), new { id = region.Id }, region);
            }
            else { return BadRequest(ModelState); }   
        }
        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> Update([FromRoute] int id, [FromBody] Region region)
        {
            if (ModelState.IsValid)
            {
                // var result = context.Regions.FirstOrDefault(r => r.Id == id);
                // if (result == null)
                // {
                //     return NotFound();
                // }

                //result.Code = region.Code;
                // result.Name = region.Name;
                // result.RegionImageUrl = region.RegionImageUrl;
                var result = await _serv.update(id, region);
                return Ok(result);
            }
            else
            { return BadRequest(ModelState); }
        }
        [HttpDelete]
        [Route("{id:int}")]
        public async Task<IActionResult> DeleteById([FromRoute] int id)
        {
            //var result = context.Regions.FirstOrDefault(r => r.Id == id);
            //if (result == null)
            //{
            //    return NotFound();
            //}
            //context.Regions.Remove(result);
            //context.SaveChanges();
            var result=await _serv.delete(id);
            return Ok(result);
        }
    }
}
