﻿
using Microsoft.AspNetCore.Mvc;
using MyTrekWeb.Data;
using MyTrekWeb.Models;

namespace MyTrekWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DifficultyController : ControllerBase
    {
        private readonly TrekDbContext _context;
        public DifficultyController(TrekDbContext context)
        {
                _context = context;
        }
        [HttpGet]
        public IActionResult Get()
        {
            var result = _context.difficulties.ToList();
            return Ok(result);
        }
        [HttpGet]
        [Route("{id:int}")]
        public IActionResult GetAllById([FromRoute] int id)
        {
            var result =_context.difficulties.FirstOrDefault(r=>r.Id==id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
        [HttpPost]
        public IActionResult create([FromBody] Difficulty difficulty)
        {
            _context.difficulties.Add(difficulty);  
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetAllById), new { id = difficulty.Id }, difficulty);
        }
        [HttpPut]
        [Route("{id:int}")]
        public IActionResult Update([FromRoute] int id, [FromBody] Difficulty difficulty)
        {
            var result = _context.difficulties.FirstOrDefault(r => r.Id == id);
            if (result == null)
            {
                return NotFound();
            }
            
            result.Name = difficulty.Name;
            return Ok(result);
        }
        [HttpDelete]
        [Route("{id:int}")]
        public IActionResult DeleteById([FromRoute] int id)
        {
            var result = _context.difficulties.FirstOrDefault(r => r.Id == id);
            if (result == null)
            {
                return NotFound();
            }
            _context.difficulties.Remove(result);   
            _context.SaveChanges();
            return Ok(result);  
        }
    }
}
