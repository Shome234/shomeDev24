﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyTrekWeb.Data;
using MyTrekWeb.Models;
using MyTrekWeb.Repository;

namespace MyTrekWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrekController : ControllerBase
    {
        private readonly ITrekRepository trekRepo;
        public TrekController(ITrekRepository repo)
        {

            trekRepo = repo;
        }
        [HttpGet]
        public  IActionResult Get([FromQuery] string? filterOn, [FromQuery] string? filterQuery, [FromQuery]string? sortBy, [FromQuery] bool? isAscending)
        {
            //var result = _context.Treks.ToList();
            //return Ok(result);  
            var result = trekRepo.Get(filterOn, filterQuery, sortBy, isAscending ?? true);
            return Ok(result);
        }
        [HttpGet]
        [Route("{id:int}")]
        public  IActionResult GetById([FromRoute] int id)
        {
            //var result = _context.Treks.FirstOrDefault(r => r.Id == id);
            var result = trekRepo.GetById(id);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
        [HttpPost]
        public IActionResult Create([FromBody] Trek trek)
        {
            //_context.Treks.Add(trek);
            //_context.SaveChanges();
            trekRepo.Create(trek);
            
            return CreatedAtAction(nameof(GetById), new {id=trek.Id} ,trek);
        }

        [HttpPut]
        [Route("{id:int}")]
        public IActionResult Update([FromRoute] int id, [FromBody] Trek trek)
        {
            //var result = _context.Treks.FirstOrDefault(r => r.Id == id);
            //if (result == null)
            //{
            //    return NotFound();
            //}

            //result.Name = trek.Name;
            //result.Description = trek.Description;
            //result.WalkImageUrl = trek.WalkImageUrl;    
            //result.LengthInKm = trek.LengthInKm;
            //return Ok(result);
            var result = trekRepo.Update(id, trek);
            return Ok(result);


        }
        [HttpDelete]
        [Route("{id:int}")]
        public IActionResult Delete([FromRoute] int id, [FromBody] Trek trek) 
        {
            //var result = _context.Treks.FirstOrDefault(r => r.Id == id);
            //if (result == null)
            //{
            //    return NotFound();
            //}
            //_context.Treks.Remove(trek);
            //_context.SaveChanges();
            var result = trekRepo.DeleteById(id);
            return Ok(result);
        }
    }
}
