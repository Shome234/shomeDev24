﻿namespace Hospital.Utility
{
    public class Class1
    {

    }
}
