﻿namespace DoctorData
{
    public class Class1
    {

    }
}
