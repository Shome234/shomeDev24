﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hospital.Models
{
    public class Departments
    {
        [Key]
        public int Id { get; set; }
        [Required]

        [DisplayName("Department")]
        public string DepartmentName { get; set; } = string.Empty;

        //public int DoctorId { get; set; }
        //[ForeignKey("DoctorId")]
        //public Doctor Doctor { get; set; }
    }
}
