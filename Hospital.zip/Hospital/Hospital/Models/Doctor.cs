﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hospital.Models
{
    public class Doctor
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [DisplayName("Doctor Name")]
        [MaxLength(30)]
        public string Name { get; set; }

        [DisplayName("Specialisation")]
        [MaxLength(50)]
        public string Specialisation { get; set; }

        [DisplayName("Hospital Name")]
        [MaxLength(50)]
        public string Hospital { get; set; }

        [DisplayName("Fees")]

        public double Fees { get; set; }

        //public int DepartmentId { get; set; }
        //[ForeignKey("DepartmentId")]
        //public Departments Department { get; set; }

    }
}
