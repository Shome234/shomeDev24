﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hospital.Migrations
{
    /// <inheritdoc />
    public partial class xyz1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Docinfo_DepartmentList_DepartmentId",
                table: "Docinfo");

            migrationBuilder.DropIndex(
                name: "IX_Docinfo_DepartmentId",
                table: "Docinfo");

            migrationBuilder.DropColumn(
                name: "DepartmentId",
                table: "Docinfo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DepartmentId",
                table: "Docinfo",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "Docinfo",
                keyColumn: "Id",
                keyValue: 1,
                column: "DepartmentId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "Docinfo",
                keyColumn: "Id",
                keyValue: 2,
                column: "DepartmentId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "Docinfo",
                keyColumn: "Id",
                keyValue: 3,
                column: "DepartmentId",
                value: 3);

            migrationBuilder.CreateIndex(
                name: "IX_Docinfo_DepartmentId",
                table: "Docinfo",
                column: "DepartmentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Docinfo_DepartmentList_DepartmentId",
                table: "Docinfo",
                column: "DepartmentId",
                principalTable: "DepartmentList",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
