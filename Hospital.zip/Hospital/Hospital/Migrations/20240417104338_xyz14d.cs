﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hospital.Migrations
{
    /// <inheritdoc />
    public partial class xyz14d : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Docinfo_Docinfo_DepartmentId",
                table: "Docinfo");

            migrationBuilder.AddForeignKey(
                name: "FK_Docinfo_DepartmentList_DepartmentId",
                table: "Docinfo",
                column: "DepartmentId",
                principalTable: "DepartmentList",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Docinfo_DepartmentList_DepartmentId",
                table: "Docinfo");

            migrationBuilder.AddForeignKey(
                name: "FK_Docinfo_Docinfo_DepartmentId",
                table: "Docinfo",
                column: "DepartmentId",
                principalTable: "Docinfo",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
