﻿using Hospital.HospitalData.Data;
using Hospital.Repository.IRepository;

namespace Hospital.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private ApplicationDbContext _db;

        public IDoctorRepository DoctorRepository {  get; set; }

        public IHospitalRepository HospitalRepository {  get; set; }

        public IDepartmentRepository DepartmentRepository { get; set; }

        public IPatientRepository patientRepository { get; set; }

        public UnitOfWork(ApplicationDbContext db)
        {
            _db = db;
            DoctorRepository = new DoctorRepository(_db);
            HospitalRepository = new HospitalRepository(_db);
            patientRepository = new PatientRepository(_db);
            DepartmentRepository = new DepartmentRepository(_db);

        }
        

        public void Save()
        {
            _db.SaveChanges();
        }
    }
}
