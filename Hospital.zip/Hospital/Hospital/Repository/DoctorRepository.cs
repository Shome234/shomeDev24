﻿using Hospital.HospitalData.Data;
using Hospital.Models;
using Hospital.Repository.IRepository;
using System.Linq.Expressions;

namespace Hospital.Repository
{
    public class DoctorRepository : Repository<Doctor>, IDoctorRepository
    {
        private ApplicationDbContext _db;
        public DoctorRepository(ApplicationDbContext db) : base(db) 
        {
            _db = db;
        }

        public void Add(Hospitals obj)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            _db.SaveChanges();
        }

        public void Update(Doctor obj)
        {
            _db.Docinfo.Update(obj);
        }

        public void Update(Hospitals obj)
        {
            throw new NotImplementedException();
        }
    }
}
