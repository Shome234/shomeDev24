﻿namespace Hospital.Repository.IRepository
{
    public interface IUnitOfWork
    {
        IDoctorRepository DoctorRepository { get; }
        IHospitalRepository HospitalRepository { get; } 
        
        IPatientRepository patientRepository { get; }
        
        IDepartmentRepository DepartmentRepository { get; }

        void Save();
    }
}
