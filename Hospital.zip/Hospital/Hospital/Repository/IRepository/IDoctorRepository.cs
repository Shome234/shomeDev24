﻿using Hospital.Models;

namespace Hospital.Repository.IRepository
{
    public interface IDoctorRepository : IRepository<Doctor>
    {
        void Update(Doctor obj);
        void Save();
        void Add(Hospitals obj);
        void Update(Hospitals obj);
    }
}
